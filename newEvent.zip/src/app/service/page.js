import ServiceSection from '@/ServiceModule';
import React from 'react'

const ServicePage = () => {
  return <>
  <ServiceSection />
  </>;
}

export default ServicePage
