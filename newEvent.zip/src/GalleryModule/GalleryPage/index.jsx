import GallarySection from '@/HomeModule/Component/GallarySection/GallarySection';
import React from 'react'

const MainGallery = () => {
  return (
    <>
      <GallarySection />
    </>
  );
}

export default MainGallery;
