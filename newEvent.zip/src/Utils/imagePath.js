import React from 'react';
import mainlogo from"../assets/logo.png";


export const imagePath = {
  mainlogo,
};

 
