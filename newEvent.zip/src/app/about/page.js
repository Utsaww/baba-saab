import MainAbout from '@/AboutModule/MainAboutSection';
import React from 'react';

const AboutPage = () => {
  return (
    <>
      <MainAbout />
    </>
  )
}

export default AboutPage
