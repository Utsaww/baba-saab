import React from 'react'
import MainContactSection from './Components/MainContactSection/MainContactSection'

const ContactSection = () => {
  return (
    <>
      <MainContactSection />
    </>
  )
}

export default ContactSection;
